$("#menu div").click(function () {
		      $(this).toggleClass("active");
		    });